Remember to open xampp and run both apache and MySQL

!important
don't run any of the sql files in phpmyadmin first
!important

when you first run the page, the code will do it automatically for you.

if you did run it first before opening, delete the database taste_trail in phpMyAdmin, and run the page

DO NOT change the folder name, otherwise the url in index.html will be incorrect

to activate add, delete, edit, use the account:
username: admin
password: 1234

Open index.html with google to reach the webpage
